import React, { useState } from 'react';
import { StyleSheet, View, FlatList, Alert, TouchableWithoutFeedback, Keyboard } from 'react-native';
import Header from './components/header';
import RecipeIngredient from './components/RecipeIngredient';
import AddToRecipe from './components/addToRecipe';

export default function App() {
  const [Ingreds, setIngreds] = useState([
    { text: 'Pepper', key: '1' },
    { text: 'Paprika', key: '2' },
    { text: 'Salt', key: '3' },
    { text: 'Onion', key: '4' },

  ]);

  const pressHandler = (key) => {
    setIngreds(prevIngred => {
      return prevIngred.filter(Ingred => Ingred.key != key);
    });
  };

  const submitHandler = (text) => {
    if(text.length > 3){
      setIngreds(prevIngred => {
        return [
          { text, key: Math.random().toString() },
          ...prevIngred
        ];
      });
    } else {
      Alert.alert('ohoh', 'Ingredients must be over 4 characters long', [
        {text: 'Understood', onPress: () => console.log('alert closed') }
      ]);
    }
  };

  return (
    <View style={styles.container}>
      <Header />
      <View style={styles.content}>
        <AddToRecipe submitHandler={submitHandler} />
        <View style={styles.list}>
          <FlatList
            data={Ingreds}
            renderIngred={({ Ingred }) => (
              <RecipeIngredient Ingred={Ingred} pressHandler={pressHandler} />
            )}
          />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  content: {
    padding: 40,
  },
  list: {
    marginTop: 20,
  },
});
